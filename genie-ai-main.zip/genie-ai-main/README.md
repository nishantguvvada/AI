# genie-ai
Uses structured data and PALM model to create visualizations and data summary.  
